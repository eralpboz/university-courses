import java.util.List;

/**
 * The Drawer class handles all visual console output for the game.
 * It contains only static methods and does not store game state.
 */
public class Drawer {

    /**
     * Prints the game instructions and controls to the console.
     */
    public static void printControls() {
        /* ... */
    }

    /**
     * Draws the current state of the game on the console.
     * This method:
     * 1. Creates a 2D char array (grid) of HEIGHT x WIDTH.
     * 2. Fills it with empty spaces.
     * 3. Places all active stars at their respective coordinates.
     * 4. Places the basket at its current coordinate.
     * 5. Calls printField to display the grid with borders.
     * * @param basket the player-controlled basket
     * @param stars  the list of active stars falling down
     * @param score  the player's current score
     */
    public static void render(Basket basket, List<Star> stars, int score) {
        // Initialize the grid using GameEngine.HEIGHT and GameEngine.WIDTH
        /* ... */
        
        // Fill grid with ' '
        /* ... */

        // Place stars and basket symbols on the grid
        /* ... */

        System.out.println();
        printField(grid);
        System.out.println("Score: " + score + " | Health: " + basket.getHealth());
    }

    /**
     * Helper method to print the 2D grid with formatted borders.
     * Each row should look exactly like this: "|          * |"
     * Ensure there are NO extra spaces around the symbol that push the walls.
     * * @param grid the 2D char array representing the game area
     */
    private static void printField(char[][] grid) {
        // Print the top border "======================"
        /* ... */

        // Iterate through the grid and print each cell between "|" walls
        // Hint: Don't forget to move to the next line after each row!
        /* ... */

        // Print the bottom border "======================"
        /* ... */
    }
}